python eval.py --checkpoint ./logs-tacotron/model.ckpt-22000 --ref ./parallel_data/wavs/clb_arctic_a0001.wav
python eval.py --checkpoint ./logs-tacotron/model.ckpt-22000 --ref ./parallel_data/wavs/clb_arctic_a0003.wav
